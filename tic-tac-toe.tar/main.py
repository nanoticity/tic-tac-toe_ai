from game import Game
import asyncio

g = Game()

asyncio.run(g.run())